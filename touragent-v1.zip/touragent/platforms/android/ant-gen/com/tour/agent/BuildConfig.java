/** Automatically generated file. DO NOT MODIFY */
package com.tour.agent;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}